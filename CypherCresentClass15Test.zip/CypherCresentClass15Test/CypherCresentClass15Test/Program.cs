﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassTestCCSAModeling;

namespace CypherCresentClass15Test
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] ArrrayOfAttendees = new string[] 
            {
             "FirstHuman", "SecondHuman", "ThirdHuman", "FourthHuman", "FirthHuman",
             "SixthHuman", "SeventhHuman", "EighthHuman", "NinthHuman", "TenthHuman",
            };

            for (int i = 1; i <= ArrrayOfAttendees.Length; i++)
            {

            }
        }
    }
}
