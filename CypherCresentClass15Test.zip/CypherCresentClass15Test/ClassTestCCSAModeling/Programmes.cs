﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassTestCCSAModeling
{
    public class Programmes
    {
        //Constructors
        public Programmes()
        {

        }
        //Methods
        public virtual void HoldClasses()
        {
            //Tuesday
            //Thursday
        }
        //Properties
        public List<Programmes> Programme { get; set; }

    }
}
