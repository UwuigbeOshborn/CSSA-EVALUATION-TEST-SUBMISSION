﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassTestCCSAModeling
{
    public class Facilitator : Human
    {
        //Constructors

        //Methods
        public override void AttendClass()
        {
        }
        public override void AskQuestion()
        {
            //To Student
        }
        public override void AnswerQuestion()
        {
            //Gives additional resources
        }
        //Properties

    }
}
