﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassTestCCSAModeling
{
    public class Classes
    {
        //Constructors

        //Methods

        //Properties

    }
    
}
