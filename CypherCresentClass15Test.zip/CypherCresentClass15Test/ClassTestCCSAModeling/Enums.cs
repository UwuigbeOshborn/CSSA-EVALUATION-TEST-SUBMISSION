﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassTestCCSAModeling
{
    public class Enums
    {
        enum WeekDays
        {
            Monday,
            Tuesday,
            Wednesday,
            Thursday,
            Friday,
            Saturday,
            Sunday
        }
        enum ClassDays
        {
            Tuesday,
            Thursday,
            Monday,
            Wednesday
        }
    }
}
