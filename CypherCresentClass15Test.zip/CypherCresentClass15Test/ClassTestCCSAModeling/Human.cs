﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassTestCCSAModeling
{
    public class Human
    {
        //Constructors

        //Methods
        public virtual void AttendClass()
        {
        }
        public virtual void AskQuestion()
        {
        }
        public virtual void AnswerQuestion()
        {
            //Explanation
        }
        //Properties
        public string Name { get; set; }
       
    }
}
