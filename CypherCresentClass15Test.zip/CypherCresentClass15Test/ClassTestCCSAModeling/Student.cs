﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassTestCCSAModeling
{
    public class Student : Human
    {
        //Constructors

        //Methods
        public override void AttendClass()
        {
        }
        public override void AskQuestion()
        {
            //To Facilitator
            //To fellow Student
        }
        public override void AnswerQuestion()
        {
        }
        //Properties
        public int MyProperty { get; set; }
    }
}
