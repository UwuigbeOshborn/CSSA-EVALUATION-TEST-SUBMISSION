﻿

// A recursion method called StringAnalyzer, which checks the length of the string input and convert the input to uppercase
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CypherCresentClass10c
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ArrayAnalyzer(1, 1, 3, 3, 4, 6, 2);
        }
        static int ArrayAnalyzer(params int[] input)
        {
            int lowestNumber;
            int highestNumber;
            int Sum;

            if (input.Length == 0)
            {
                return 1;
            }
            else
            {
                if (true)
                {

                }
                lowestNumber = input.Min();
                highestNumber = input.Max();
                Sum = lowestNumber + highestNumber;
                Console.Write("The current state of the string is: " + Sum + "\n");
                input.Where(x => x == 0).ToArray();
                ArrayAnalyzer(input);
                return 2;
            }
        }
    }
}
/*
// A recursion method called StringAnalyzer, which checks the length of the string input and convert the input to uppercase
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CypherCresentClass10c
{
    internal class Program
    {
        static void Main(string[] args)
        {
            StringAnalyzer(1,1,3,3,4,6,2);
        }
        static int StringAnalyzer(params int[] input)
        {
            int count;
            int countHolder;
            int lowestNumber;
            int highestNumber;
            int Sum;

            count = 0;
            countHolder = count; 
            if (input.Length == 0)
            {
                return 1;
            }
            else
            {
                if (input[countHolder] > input[countHolder + 1])
                {
                    lowestNumber = input[countHolder];
                    highestNumber = input[countHolder + 1];

                    Sum = lowestNumber + highestNumber;
                    Console.Write("The sum of the lowest and highest number of the array is: " + Sum + "\n");
                }
                _ = input.Length -= 1;
                Console.Write("The count of the array is:{0}\n", count);
                count = 1 + StringAnalyzer(input);
                return 2;
            }
        }
    }
}
*/
/*
 
// A recursion method called StringAnalyzer, which checks the length of the string input and convert the input to uppercase
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CypherCresentClass10c
{
    internal class Program
    {
        static void Main(string[] args)
        {
            StringAnalyzer(1,1,3,3,4,6,2);
        }
        static int StringAnalyzer(params int[] input)
        {
            int count;
            int countHolder;
            int lowestNumber;
            int highestNumber;
            int Sum;

            count = 0;
            countHolder = count; 
            if (input.Length == count + 1)
            {
                return 1;
            }
            else
            {
                if (input[countHolder] > input[countHolder + 1])
                {
                    lowestNumber = input[countHolder];
                    highestNumber = input[countHolder + 1];

                    Sum = lowestNumber + highestNumber;
                    Console.Write("The sum of the lowest and highest number of the array is: " + Sum + "\n");
                }

                Console.Write("The count of the array is:{0}\n", count);
                count = 1 + StringAnalyzer(input);
                return 2;
            }
        }
    }
}
 */
/*
 
// A recursion method called StringAnalyzer, which checks the length of the string input and convert the input to uppercase
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CypherCresentClass10c
{
    internal class Program
    {
        static void Main(string[] args)
        {
            StringAnalyzer(1,1,3,3,4,6,2);
        }
        static int StringAnalyzer(params int[] input)
        {
            int count;
            int countHolder;
            int lowestNumber = 0;
            int highestNumber = 0;
            int Sum;

            count = 0;
            countHolder = count; 
            if (input.Length == countHolder + 1)
            {
                return 1;
            }
            else
            {
                if (input[countHolder] > input[countHolder + 1])
                {
                    highestNumber = input[countHolder];
                }
                if (input[countHolder] > input[countHolder + 1])
                {
                    highestNumber = input[countHolder];
                }
                Sum = lowestNumber + highestNumber;
                Console.Write("The sum of the lowest and highest number of the array is: " + Sum + "\n");
                count = 1 + StringAnalyzer(input);
                return 2;
            }
        }
    }
}
 */
/*
 
// A recursion method called StringAnalyzer, which checks the length of the string input and convert the input to uppercase
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CypherCresentClass10c
{
    internal class Program
    {
        static void Main(string[] args)
        {
            StringAnalyzer(1,1,3,3,4,6,2);
        }
        static int StringAnalyzer(params int[] input)
        {
            int count;
            int lowestNumber;
            int highestNumber;
            int Sum;
            if (input.Length == count)
            {
                return 1;
            }
            else
            {
                if (true)
                {

                }
                lowestNumber = input.Min();
                highestNumber = input.Max();
                Sum = lowestNumber + highestNumber;
                Console.Write("The current state of the string is: " + Sum + "\n");
                Sum = 1 + StringAnalyzer(input);
                Console.Write("The length of the string is:{0}\n", count);
                return count;
            }
        }
    }
}
 */
/*
// A recursion method called StringAnalyzer, which checks the length of the string input and convert the input to uppercase
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CypherCresentClass10c
{
    internal class Program
    {
        static void Main(string[] args)
        {
            StringAnalyzer("My world needs you");
        }
        static int StringAnalyzer(string input)
        {
            int count;
            if (input == "")
            {
                return 1;
            }
            else
            {
                input = input.Remove(0, 1);
                Console.Write("The current state of the string is: " + input + "\n");
                count = 1 + StringAnalyzer(input);
                Console.Write("The length of the string is:{0}\n", count);
                return count;
            }
        }
    }
}
*/