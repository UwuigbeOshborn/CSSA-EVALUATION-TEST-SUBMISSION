﻿// A recursion method called StringAnalyzer, which checks the length of the string input and convert the input to uppercase
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CypherCresentClass10c
{
    internal class Program
    {
        static void Main(string[] args)
        {
            StringAnalyzer("My world needs you");
        }
        static int StringAnalyzer(string input)
        {
            int count;
            if (input == "")
            {
                return 1;
            }
            else
            {
                input = input.Remove(0, 1);
                Console.Write("The current state of the string is: " + input + "\n");
                count = 1 + StringAnalyzer(input);
                Console.Write("The length of the string is:{0}\n", count);
                return count;
            }
        }
    }
}