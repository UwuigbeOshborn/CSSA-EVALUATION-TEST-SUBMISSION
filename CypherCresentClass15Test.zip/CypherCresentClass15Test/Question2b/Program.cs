﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question2b
{
    internal class Program
    {
        static void Main(string[] args)
        {
            StringAnalyzer("My 234 needs you");
        }
        static void StringAnalyzer(string input)
        {
            int countNumbers;
            bool CheckForNumbers;
            bool CheckForText;
            int countText;
            string newString;

            
            countNumbers = 0;
            countText = 0;
            newString = "";
            foreach (var item in input)
            {
                string str = item.ToString();   
                CheckForNumbers = int.TryParse(str, out int n);
                if (CheckForNumbers == true)
                {
                    countNumbers += 1;
                }
                CheckForText =  char.TryParse(str, out char n2);
                if (CheckForText == true)
                {
                    countText += 1;
                }
            }
            Console.Write("The number of integers in string input = {0}\n", countNumbers);
            Console.Write("The number of texts in string input = {0}\n", countText);
        }
    }
}

